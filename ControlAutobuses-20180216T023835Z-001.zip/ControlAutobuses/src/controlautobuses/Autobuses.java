/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controlautobuses;

/**
 *
 * @author alumnog
 */
public class Autobuses  {

 String id;
 String capacidad;
 String categoria;
 String chofer;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(String capacidad) {
        this.capacidad = capacidad;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getChofer() {
        return chofer;
    }

    public void setChofer(String chofer) {
        this.chofer = chofer;
    }
    
    
}
