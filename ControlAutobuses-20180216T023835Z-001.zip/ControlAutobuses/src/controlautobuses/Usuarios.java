/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controlautobuses;


public class Usuarios {
    
    String nombre;
    String edad;
    String direccion;
    String equipaje;
}
