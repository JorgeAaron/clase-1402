
package controlautobuses;

public class ControlAutobuses {

    
    public static void main(String[] args) {
        
    }
}
