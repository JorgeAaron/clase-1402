
package controlautobuses;


public class Viajes extends Autobuses {
    
    String Destino;
    String Origen;
    String HoraSali;
    String HoraLleg;
    double Precio;
    
}
